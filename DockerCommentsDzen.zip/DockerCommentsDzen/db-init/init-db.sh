#!/usr/bin/env bash
set -e

# Locate sqlcmd regardless of the exact tools version baked into the mssql image
SQLCMD="$(find / -maxdepth 6 -type f -name sqlcmd 2>/dev/null | head -n 1)"
if [ -z "$SQLCMD" ]; then
  echo "sqlcmd not found in image" >&2
  exit 1
fi

echo "Using sqlcmd at: $SQLCMD"

echo "Creating database CommentDb if it does not exist..."
"$SQLCMD" -S db -U sa -P "$MSSQL_SA_PASSWORD" -C -No -Q "IF DB_ID(N'CommentDb') IS NULL CREATE DATABASE CommentDb;"

echo "Applying SchemaCommentDb.sql..."
"$SQLCMD" -S db -U sa -P "$MSSQL_SA_PASSWORD" -C -No -i /schema/SchemaCommentDb.sql

echo "Database schema is ready."
